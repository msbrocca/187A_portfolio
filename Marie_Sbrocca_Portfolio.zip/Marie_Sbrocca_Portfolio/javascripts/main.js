$(document).ready(function() {

  /*Put your Javascript code here*/

  /*
    Simple image gallery. Use default settings
  */
  $('.fancybox').fancybox();

});
